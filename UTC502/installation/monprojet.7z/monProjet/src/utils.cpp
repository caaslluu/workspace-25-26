#include <iostream>
#include "utils.h"
 
void afficherMessage() {
    std::cout << "Fonction utils.cpp appelée avec succès ✅" << std::endl;
}
