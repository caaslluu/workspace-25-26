#include <iostream>
#include "utils.h"
 
int main() {
    std::cout << "Hello from MonProjet" << std::endl;
    afficherMessage();
    return 0;
}
