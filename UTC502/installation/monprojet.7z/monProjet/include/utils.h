#ifndef UTILS_H
#define UTILS_H
 
void afficherMessage();
 
#endif
