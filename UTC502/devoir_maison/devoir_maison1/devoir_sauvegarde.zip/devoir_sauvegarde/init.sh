mkdir -p rep_src rep_dest
echo "petit test pour voir si ça marche bien" > rep_src/file.txt
