/*
Objectif du programme
=====================
/!\ A donner en TD /!\
Donner le code d'un exemple d'utilisation de la primitive setpriority().
Conseil : s'inspirer du programme exemple-getpriority.c

Commentaire sur le code
========================
#include <sys/wait.h>
int setpriority(int classe, int pid, int prio);

- Décrire les arguments de la primitive setpriority()
- Quels sont  les valeurs de retour


Sortie du programme
===================

Fournir la sortie du programme.

*/